int main(void) {
    return 31;
}
