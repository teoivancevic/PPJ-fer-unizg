int main(void) {
    int x = 0;
    int i;
    for (i=0; i<42; ++i) {
        x = x + 2;
    }
    return x;
}
