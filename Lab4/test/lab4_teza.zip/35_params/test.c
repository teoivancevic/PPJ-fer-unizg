int f(int x, int y, int z, int a, int b, int c, int d) {
    return x + y + d + c + a + b;
}
int main(void) {
    return f(1, 2, 3, 4, 5, 6, 7);
}
