int main(void) {
    if (0) {
        return 123;
    }
    return 21;
}
