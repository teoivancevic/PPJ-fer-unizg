int x = 27;
int y = 65;
int main(void) {
    return x&y;
}
