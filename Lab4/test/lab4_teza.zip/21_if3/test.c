int x = 1234;
int y = 12345;
int main(void) {
    if (x < y) {
        return 12;
    } else {
        return 21;
    }
    return 9;
}
