int x = 2;
char c = 'a';
int main(void) {
    return c + x;
}
