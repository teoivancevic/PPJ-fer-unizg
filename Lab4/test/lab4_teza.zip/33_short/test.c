int main(void) {
    int x = 15;
    x>=3 || (x=1);
    x<15 && (x=2);
    return x;
}
