int x = 12;
int main(void) {
    int x = 123;
    {
        int x = 32;
        return x;
    }
}
