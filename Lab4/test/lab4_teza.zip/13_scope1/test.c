int x = 12;
int f(void) {
    int x = 167;
    return x;
}
int main(void) {
    return f();
}
