int x = 15;
int y = 12;
int main(void) {
    return x-y;
}
