int f(void) {
    return 123;
}
int main(void) {
    return f();
}
