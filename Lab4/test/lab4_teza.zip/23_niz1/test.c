char a[5] = {'a', 'b', 'c', 'd', 'e'};
int main(void) {
    return a[1];
}
