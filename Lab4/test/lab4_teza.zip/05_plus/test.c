int x = 15;
int y = 16;
int main(void) {
    return x+y;
}
