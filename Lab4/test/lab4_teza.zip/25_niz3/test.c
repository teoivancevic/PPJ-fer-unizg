int a[5];
int main(void) {
    a[0] = 0;
    a[4] = 123;
    a[2] = 1;
    return a[0] + a[4] + a[2];
}
