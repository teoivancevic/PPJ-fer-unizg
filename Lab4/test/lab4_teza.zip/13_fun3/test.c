int f(int x) {
    return x + 5;
}
int main(void) {
    return f(7) + f(-4);
}
