#include "Types.hpp"

const TypeInfo TypeInfo::VOID = TypeInfo(BasicType::VOID);
