char f(void) {
    return 'a';
}
int f2(void) {
    char c = f(); // ok
    return 0;
}
// main
