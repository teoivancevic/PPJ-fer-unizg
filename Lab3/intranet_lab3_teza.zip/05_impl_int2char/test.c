int main(void) {
    char c = 'a'; // ok
    char cc = c + 1; // char + int --> int -(greska)-> char
    return 0;
}
