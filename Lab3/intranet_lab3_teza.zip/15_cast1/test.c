int main(void) {
    char c = (const char)('a' + 1);
    int x = (char)(const char)(const int)(int)c + 1;
    return (int)main;
}
