int main(void) {
    int a[5];
    a[0] = a[1]; // nedefiniran rezultat, ali ok
    return a; // greska u tipu
}
