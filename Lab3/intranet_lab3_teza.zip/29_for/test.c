int main(void) {
    int i, y=0;
    for (i=0; i<10; ++i) {
        i = i + 1;
        y = y + 2;
    }
    for (i=0; main; ++i) {
        y = 1;
    }
    return y;
}
